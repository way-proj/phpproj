<?php $this->load->view('include/header'); ?>
<!--  ####################### load page ##########################   -->
<?php $this->load->view($subview);?>
<!--  ####################### load page ##########################   -->
<?php $this->load->view('include/footer'); ?>
