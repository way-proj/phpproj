

            <!--Search popup start-->

            <div id="myOverlay" class="overlay_1">
                <span class="closebtn" onclick="closeSearch()" title="Close Overlay">x</span>
                <div class="overlay-content">
                  <form action="/action_page.php">
                    <input type="text" placeholder="Search.." name="search">
                    <button type="submit"><i class="fa fa-search"></i></button>
                  </form>
                </div>
              </div>
<!--Search popup End-->
            <section class="vc_custom1 about-m">
              <div id="spc"></div>
              <div class="about-title">
                  <h1>Details</h1>
                  <h4 id="link"><a href="">Home</a>&nbsp;&nbsp; > &nbsp;&nbsp;My Account</h4>
                  </div>
                  <div id="spc"></div>
              </section>
      
              <div style="height: 70px;"></div>
              <div class="container">
                  <div class="row">
                    
                       
                     <?php $this->load->view('include/left_sidebar'); ?>
                          <div class="col-md-9 col-sm-9 useraccount">
                              <div class="details-area bg-white mycredit">
                                <h4>My Credit</h4>
                                <hr>
                                <div class="credits-table">
                                    <div class="credits-table-heading ">
                                       <div class="credits-table-row heading-row ">
                                          <div class="credits-table-head-cell ">USER ID#</div>
                                          <div class="credits-table-head-cell">PRICE</div>
                                          <div class="credits-table-head-cell">CREATED AT</div>
                                          <div class="credits-table-head-cell">CURRENCY</div>
                                          <div class="credits-table-head-cell">NARRATION</div>
                                       </div>
                                    </div>
                                    <div class="credits-table-body">
                                       <div class="credits-table-row even-row" id="credit-row">
                                          <div class="credits-table-cell first-row-gap table-cell-gap"><span class="user-id">1234325671</span></div>
                                          <div class="credits-table-cell">₹100.00</div>
                                          <div class="credits-table-cell">20-May-2020</div>
                                          <div class="credits-table-cell">INR</div>
                                          <div class="credits-table-cell">Cash in account for the new user</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="flex-row center-flex center policy-para-container">
                                    <p class="policy-para"> In case you want to know more about your order, return any item or cancel the order for whatever reasons, please do not hesitate to call us at <span class="mail-us">0 1234 67890</span> (Mon-Sat: 10:00 AM to 7:00 PM IST). Or drop us an email at <span class="mail-us"><a href="mailto:help@gmail.com" class="mail-us">help@gmail.com.</a></span></p>
                                 </div>
                                  </div>
                              </div>
                      </div>
                  </div> 
                  <div style="height: 70px;"></div>
    <!-- Footer -->
<div class="g-bg-black-opacity-0_9 g-color-white-opacity-0_8 g-py-60">
    <div class="container">
      <div class="row">
        <!-- Footer Content -->
        <div class="col-lg-3 col-md-6 g-mb-40 g-mb-0--lg">
          <div class="u-heading-v3-1 g-brd-white-opacity-0_3 g-mb-25">
            <h2 class="u-heading-v3__title h6 text-uppercase g-brd-primary">About-us</h2>
          </div>
          <p>About Unify dolor sit amet, consectetur adipiscing elit. Maecenas eget nisl id libero tincidunt sodales.</p>
          <p class="mb-0">Duis eleifend fermentum ante ut aliquam. Cras mi risus, dignissim sed adipiscing ut, placerat non arcu.</p>
        </div>
        <!-- End Footer Content -->
  
        <!-- Footer Content -->
        <div class="col-lg-3 col-md-6 g-mb-40 g-mb-0--lg">
          <div class="u-heading-v3-1 g-brd-white-opacity-0_3 g-mb-25">
            <h2 class="u-heading-v3__title h6 text-uppercase g-brd-primary">Latest Posts</h2>
          </div>
  
          <article>
            <h3 class="h6 g-mb-2">
              <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">Incredible template</a>
            </h3>
            <div class="small g-color-white-opacity-0_6">May 8, 2017</div>
          </article>
  
          <hr class="g-brd-white-opacity-0_1 g-my-10">
  
          <article>
            <h3 class="h6 g-mb-2">
              <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">New features</a>
            </h3>
            <div class="small g-color-white-opacity-0_6">June 23, 2017</div>
          </article>
  
          <hr class="g-brd-white-opacity-0_1 g-my-10">
  
          <article>
            <h3 class="h6 g-mb-2">
              <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">New terms and conditions</a>
            </h3>
            <div class="small g-color-white-opacity-0_6">September 15, 2017</div>
          </article>
        </div>
        <!-- End Footer Content -->
  
        <!-- Footer Content -->
        <div class="col-lg-3 col-md-6 g-mb-40 g-mb-0--lg">
          <div class="u-heading-v3-1 g-brd-white-opacity-0_3 g-mb-25">
            <h2 class="u-heading-v3__title h6 text-uppercase g-brd-primary">Useful Links</h2>
          </div>
  
          <nav class="text-uppercase1">
            <ul class="list-unstyled g-mt-minus-10 mb-0">
              <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                <h4 class="h6 g-pr-20 mb-0">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">About Us</a>
                  <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                </h4>
              </li>
              <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                <h4 class="h6 g-pr-20 mb-0">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">Portfolio</a>
                  <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                </h4>
              </li>
              <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                <h4 class="h6 g-pr-20 mb-0">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">Our Services</a>
                  <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                </h4>
              </li>
              <li class="g-pos-rel g-brd-bottom g-brd-white-opacity-0_1 g-py-10">
                <h4 class="h6 g-pr-20 mb-0">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">Latest Jobs</a>
                  <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                </h4>
              </li>
              <li class="g-pos-rel g-py-10">
                <h4 class="h6 g-pr-20 mb-0">
                  <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">Contact Us</a>
                  <i class="fa fa-angle-right g-absolute-centered--y g-right-0"></i>
                </h4>
              </li>
            </ul>
          </nav>
        </div>
        <!-- End Footer Content -->
  
        <!-- Footer Content -->
        <div class="col-lg-3 col-md-6">
          <div class="u-heading-v3-1 g-brd-white-opacity-0_3 g-mb-25">
            <h2 class="u-heading-v3__title h6 text-uppercase g-brd-primary">Our Contacts</h2>
          </div>
  
          <address class="g-bg-no-repeat g-font-size-12 mb-0" style="background-image: url(img/map2.png);">
            <!-- Location -->
            <div class="d-flex g-mb-20">
              <div class="g-mr-10">
                <span class="u-icon-v3 u-icon-size--xs g-bg-white-opacity-0_1 g-color-white-opacity-0_6">
                  <i class="fa fa-map-marker"></i>
                </span>
              </div>
              <p class="mb-0">795 Folsom Ave, Suite 600,
                <br>
                San Francisco, CA 94107 795
              </p>
            </div>
            <!-- End Location -->

            <!-- Phone -->
            <div class="d-flex g-mb-20">
              <div class="g-mr-10">
                <span class="u-icon-v3 u-icon-size--xs g-bg-white-opacity-0_1 g-color-white-opacity-0_6">
                  <i class="fa fa-phone"></i>
                </span>
              </div>
              <p class="mb-0">(+123) 456 7890
                <br>
                (+123) 456 7891
              </p>
            </div>
            <!-- End Phone -->

            <!-- Email and Website -->
            <div class="d-flex g-mb-20">
              <div class="g-mr-10">
                <span class="u-icon-v3 u-icon-size--xs g-bg-white-opacity-0_1 g-color-white-opacity-0_6">
                  <i class="fa fa-globe"></i>
                </span>
              </div>
              <p class="mb-0">
                <a class="g-color-white-opacity-0_8 g-color-white--hover" href="mailto:info@htmlstream.com">info@htmlstream.com</a>
                <br>
                <a class="g-color-white-opacity-0_8 g-color-white--hover" href="#!">www.htmlstream.com</a>
              </p>
            </div>
            <!-- End Email and Website -->
          </address>
        </div>
        <!-- End Footer Content -->
      </div>
    </div>
  </div>
  <!-- End Footer -->
  
 