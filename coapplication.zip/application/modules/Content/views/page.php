
				  <?php
            //print_r($category_data);

          ?>
				  <?php echo $contents;?>
					   
					 
           <!-- ===============Main content End================== -->
          
           <!----===========:FOOTER:=========---->
