 <div class="content">
 <!-- registration -->
    <div class="main-1">
        <div class="container">
            <div class="register">
               <?php echo $statusMsg; ?>
            
           </div>
         </div>
    </div>
<!-- registration -->


</div>
  
