
         <main id='main-wrapper'>
            <div class='store-locator-form store-locator-form-details'>
               <div class='sl-container'>
                  <img class='mob-hide' src='<?php echo base_url();?>/static_images/455/original/store_locator12ce4.webp?1574770564'>
                  <img alt='' class='desk-hide' src='<?php echo base_url();?>/static_images/456/original/store_locator2d933.webp?1574770577'>
                  <h2 class='section-heading inner-heading account-heading desk-hide'>
                     <span class='heading02'>Store Locator</span>
                  </h2>
               </div>
               <div class='sl-form'>
                  <h2 class='section-heading inner-heading account-heading mob-hide'>
                     <span class='heading02'>Store Locator</span>
                  </h2>
                  <p class='store-sepretor'>
                     <i class='info-icon'>
                     <img alt='' src='images/info_icon.html'>
                     </i>
                  </p>
                  <p class='selected-city'>
                   
                  </p>
                  <p class='selected-area'>
                    
                  </p>
               </div>
            </div>
            <div class='sl-wrapper' style='background: #fff;'>
               <div class='container'>
                  <ul class='bread-cum'>
                     <li>
                        <a href='<?php echo base_url();?>'>Home</a>
                     </li>
                     <li>Store Locator</li>
                  </ul>
               </div>
               <div class='sl-section sl-section-detail'>
                  <div class='container'>
                     <div class='sl-left'>
                        <div class='sl-scroll'>
                           <div class='sl-box'>
                              <h1>
                                 Jamae Raja
                              </h1>
                              <div class='sl-address'>
                                 <h2 class='location-addr'>
                                  HARISHABHA COMMERCIAL COMPLEX,SABZI BAGH,PATNA,BIHAR,800004(7070886788)<br>
                                  JAIL ROAD,ARRAH,BIHAR,802301(7367877864)

                                 </h2>
                                 <p>
                                    <span>Contact</span>
                                   7070886788
                                 </p>
                                 <p>
                                    <span>Store Hours</span>
                                    11:00 AM - 8:00 PM
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class='sl-img-box'>
                        <img alt='' src='<?php echo base_url();?>images/store_locator.webp'>
                     </div>
                     <div class='sl-map'>
                      <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d7002.142111670649!2d77.23064582620579!3d28.65759102407432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sjamae%20raja!5e0!3m2!1sen!2sin!4v1580797814290!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                     </div>
                  </div>
               </div>
            </div>
            <div class='about-strore-wrapper'>
               <div class='container'>
                  <h3 class='heading03'>About Store</h3>
                  <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.</p>
               </div>
            </div>
            <div class='sl-note-section'>
               <div class='container'>
                  <div class='sl-note'>
                     <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                     </p>
                     <h4>For any further queries you can</h4>
                     <p class='sl-email'>
                        Email us at
                        <a href='mailto:info@manyavar.com'>info@wayinfotech.com</a>
                        or call us at our toll free number
                        <a href='tel:1800120000500'>0000 000 000 000</a>
                        (for India callers only, 10:00 am – 7:00 pm IST)
                     </p>
                  </div>
               </div>
            </div>
         </main>
        