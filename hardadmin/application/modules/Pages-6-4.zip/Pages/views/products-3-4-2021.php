<section class="products-hero-section service-hero-section" style="background-image: url(<?php echo site_url(); ?>common/img/hardware-vs-software.webp)">
		<div class="container">
			<div class="h-h-content-box">
				<div class="h-h-c-b-box">
					<div class="inner-page-head-box">
						<h1>Products</h1>
						<div class="page-bredcrumb-box">
							<ul>
								<li><a href="<?php echo base_url(); ?>">Home</a></li>
								<li><a href="<?php echo base_url(); ?>products">Products</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<section class="products-slider-section">
		<div class="container">
			<h2>Popular Products</h2>
			<div class="owl-carousel owl-theme pop-prod-owl">
			<?php 
			//print_r($rows);die;
			if(!$this->uri->segment(3))
			{
			foreach($rows as $key=>$value){?>
				<div class="item pop-prod-item">
					<div class="prod-item-box">
						<div class="prod-action">
							<button type="button" data-bs-toggle="modal" data-bs-target="#talk-modal">
								<img src="<?php echo base_url(); ?>common/img/f-btn-icon.svg" alt="">
							</button>
						</div>
						<div class="img-box">
							<img src="<?php echo site_url(); ?>admin/upload/product_images/<?php echo $value['image'];?>" alt="">
						</div>
						<h1><?php echo $value['product_name'];?></h1>
						<span class="modelnm"><?php echo $value['model'];?></span>
						<a href="<?php echo site_url(); ?>Pages/getProductDetails/<?php echo $value['id'];?>" class="link-btn"> Know More </a>
					</div>
				</div>
			<?php } } else { ?>
			
			
			<?php 
			//print_r($productData);
			foreach($productData as $key=>$value){?>
				<div class="item pop-prod-item">
					<div class="prod-item-box">
						<div class="prod-action">
							<button type="button" data-bs-toggle="modal" data-bs-target="#talk-modal">
								<img src="<?php echo base_url(); ?>common/img/f-btn-icon.svg" alt="">
							</button>
						</div>
						<div class="img-box">
							<img src="<?php echo site_url(); ?>admin/upload/product_images/<?php echo $value->image;?>" alt="">
						</div>
						<h1><?php echo $value->product_name;?></h1>
						<span class="modelnm"><?php echo $value->model;?></span>
						<a href="<?php echo site_url(); ?>Pages/getProductDetails/<?php echo $value->id;?>" class="link-btn"> Know More </a>
					</div>
				</div>
			<?php } } ?>
			
			

			</div>
		</div>
	</section>

	<section class="service-info-section">
		<div class="container">

			<h1 class="service-inner-big-heading show-on-scroll scroll-animate is-visible">Giving Smartness
				<br>to your Business<b>.</b></h1>

			<p class="show-on-scroll scroll-animate is-visible">WAYINFOTECH SOLUTIONS team provides a suite of services connecting devices, applications, people and processes. Our expertise will help transform your business through effective implementation of technologies, platforms and architecture.</p>

			<!--<a href="#" class="glow-btn show-on-scroll scroll-animate is-visible">Get A Quote</a>-->
			<a class="glow-btn show-on-scroll scroll-animate is-visible" href="#" type="button" data-bs-toggle="modal" data-bs-target="#talk-modal">Get A Quote</a>	
		</div>
	</section>

	<section class="all-products-section">
		<div class="container">
			<div class="mobile-filters">
				<button class="m-f-menu" onclick="openProductsFilters()"><span class="material-icons">filter_alt</span> Filters</button>
	
				<div id="FilterMenu" class="mob-side-menu">
					<div class="mobe-side-menu-container">
						<div class="close-mob-menus" onclick="closeProductsFilters()"></div>
						<div class="mob-side-menu-block">
							<div class="mob-side-menu-box">
								<div class="mob--menu-header">
									<h1>Filters</h1>
									<button onclick="closeProductsFilters()" class="mob-menu-close-btn">X</button>
								</div>
								
						<div class="filter-body">
							<div class="filter-block">
								<h5>Industry Type</h5>
							<ul class="tags-list" id="myBtnContainer">
									<?php 
									foreach($indtype as $key=>$value){?> 
									<li class="tag-btn active">
										<button class="tag"  type="button">
									
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span><?php echo $value->industrytype_title;?></span>
										</button>
										<input type="hidden" name="indtype_id" id="indtype_id" value="<?php echo $value->id;?>">
									</li>
									<?php } ?>
									
								</ul>
							</div>
							<div class="filter-block">
								<h5>Category</h5>
								<ul class="category-list">
								<?php
								$cat_data=getcatname('category_details','id,category_name');
								  foreach ($cat_data as $key => $value) {
									$sss=str_replace(' ', '', @$value->category_name);
									$ss=str_replace('&', '', @$sss);
								?>
									<li>
										<button>
											<?php echo $value->category_name;?>
										</button>
									</li>
									<?php } ?>
								</ul>
							</div>
						</div>
							</div>
						</div>
					</div>
				  </div>
			</div>

			<div class="row">
				<div class="col-md-4 d-none d-md-block">
					<div class="desk-filters">
						<div class="filter-header">
							<h1>Filters</h1>
						</div>
						<div class="filter-body">
							<div class="filter-block">
								<h5>Industry Type</h5>
								<ul class="tags-list" id="myBtnContainer">
									<?php 
									foreach($indtype as $key=>$value){?> 
									<li class="tag-btn active">
										<button class="tag"  type="button">
									
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<!--<span><?php echo $value->industrytype_title;?></span>-->
										<span onclick="getBrandID(<?php echo $value->id;?>)"><?php echo $value->industrytype_title;?></span>	
										</button>
										<input type="hidden" name="indtype_id" id="indtype_id" value="<?php echo $value->id;?>">
									</li>
									<?php } ?>
								
								</ul>
							</div>
							<div class="filter-block">
								<h5>Category</h5>
								<ul class="category-list">
									<?php
								$cat_data=getcatname('category_details','id,category_name');
								  foreach ($cat_data as $key => $value) {
									$sss=str_replace(' ', '', @$value->category_name);
									$ss=str_replace('&', '', @$sss);
								?>
									<li onclick="get_data_by_catID(<?php echo $value->id;?>)" class="catid">
									<button>
									<?php echo $value->category_name;?>
									</button>
								<?php } ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<div class="products-info-header">
						<div class="results-count">
							Showing 4 products out of 72
						</div>
						<div class="dropdown sort-dropdown">
							<a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
								<span class="material-icons">sort</span> Sort By</a>
							<ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
							  <li><a class="dropdown-item" href="#">By Name</a></li>
							  <li><a class="dropdown-item" href="#">Recently Added</a></li>
							  <li><a class="dropdown-item" href="#">Popularity</a></li>
							</ul>
						  </div>
					</div>
					<div class="products-body">
					<div class="product-block" id="filter_result">
						<?php //foreach($rows as $key=>$value){
								foreach($rows_by_industry as $key=>$value){?>
							<div class=" prod-item-box product-box education"> 
								<div class="img-box">
									<img src="<?php echo site_url(); ?>admin/upload/product_images/<?php echo $value['image'];?>" alt="">
								</div>
								<h1><?php echo $value['product_name'];?></h1>
								<span class="modelnm"><?php echo $value['model'];?></span>
								<table>
									<tr>
										<td>Dimension:</td>
										<td>197x184x273 mm</td>
									</tr>
									<tr>
										<td>Humidity:</td>
										<td>10-90 %</td>
									</tr>
									<tr>
										<td>Media Thickness:</td>
										<td>0.18 mm</td>
									</tr>
								</table>
								<ul class="tags-list">
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span><?php echo $value['industrytype_title'];?></span>
										</a>
									</li>
									<!--<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>-->
								</ul>
								<a href="<?php echo site_url(); ?>Pages/getProductDetails/<?php echo $value['id'];?>" class="link-btn"> Know More </a>
								<div class="prod-action">
									<button class="img-box" type="button" data-bs-toggle="modal" data-bs-target="#talk-modal">
										<img src="<?php echo base_url(); ?>common/img/f-btn-icon.svg" alt="">
									</button>
								</div>
							</div>
							<?php } ?>
							<!--<div class=" prod-item-box product-box transportation"> 
								<div class="img-box">
									<img src="<?php echo base_url(); ?>common/img/products/1.png" alt="Product">
								</div>
								<h1>Zebra Barcode Label Printer</h1>
								<span class="modelnm">ZM 400</span>
								<table>
									<tr>
										<td>Dimension:</td>
										<td>197x184x273 mm</td>
									</tr>
									<tr>
										<td>Humidity:</td>
										<td>10-90 %</td>
									</tr>
									<tr>
										<td>Media Thickness:</td>
										<td>0.18 mm</td>
									</tr>
								</table>
								<ul class="tags-list">
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
								</ul>
								<a href="product-inner.html" class="link-btn">Know More</a>
								<div class="prod-action">
									<button class="img-box" type="button" data-bs-toggle="modal" data-bs-target="#talk-modal">
										<img src="<?php echo base_url(); ?>common/img/f-btn-icon.svg" alt="">
									</button>
								</div>
							</div>
							<div class=" prod-item-box product-box retail"> 
								<div class="img-box">
									<img src="<?php echo base_url(); ?>common/img/products/1.png" alt="Product">
								</div>
								<h1>Zebra Barcode Label Printer</h1>
								<span class="modelnm">ZM 400</span>
								<table>
									<tr>
										<td>Dimension:</td>
										<td>197x184x273 mm</td>
									</tr>
									<tr>
										<td>Humidity:</td>
										<td>10-90 %</td>
									</tr>
									<tr>
										<td>Media Thickness:</td>
										<td>0.18 mm</td>
									</tr>
								</table>
								<ul class="tags-list">
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
									<li>
										<a href="#" class="tag">
											<div class="img-box">
												<img src="<?php echo base_url(); ?>common/img/key-points/5.svg" alt="">
											</div>
											<span>Education</span>
										</a>
									</li>
								</ul>
								<a href="product-inner.html" class="link-btn">Know More</a>
								<div class="prod-action">
									<button class="img-box" type="button" data-bs-toggle="modal" data-bs-target="#talk-modal">
										<img src="<?php echo base_url(); ?>common/img/f-btn-icon.svg" alt="">
									</button>
								</div>
							</div>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<script>
 function get_data_by_catID(cat_id){
	        //alert(cat_id);
		//	var cat_id=$(".catid").val();
		//	alert(cat_id);
	         $.ajax({
				 url:"<?php echo base_url();?>"+'Pages/ajaxProduct',
                type:"post",
				data:{cat_id:cat_id},
				success:function(res){
					//alert(res);
                  $("#filter_result").html(res);
				  var cid = $(".cat_id").val(cat_id);
                   
                }
        });
 } 
 
function getBrandID(id){
	       // alert(id);
			$.ajax({
				url:"<?php echo base_url();?>"+'Pages/filter_product',
                type:"post",
				data:{bid:id},
				success:function(res){
					//alert(res);
					$(".bid").val(id);
					$("#filter_result").html(res);
                  
                }
        });
 } 
  
</script>                  	
