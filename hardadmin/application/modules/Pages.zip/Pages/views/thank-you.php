<section class="homepage-hero-section service-hero-section inner-section service-inner-section" style="background-image: url(<?php echo site_url(); ?>common/img/service-inner.webp)">
		<div class="container">
			<div class="h-h-content-box">
				<div class="h-h-c-b-box">
					<div class="inner-page-head-box">
						<h1>Thank You</h1>
						<div class="page-bredcrumb-box">
							<ul>
								<li><a href="<?php echo site_url(); ?>">Home</a></li>
								<li><a href="<?php echo base_url(); ?>Pages/thankyou">Thank You</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<section class="service-inner-detail-block">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 text-center">
					<h2>Thank you for getting in touch! </h2>
					<p>We appreciate you contacting us Wayinfotech Solutions. One of our Team member will get back in touch with you soon!<br/>
							Have a great day!</p>
				</div>
			</div>
		</div>
	</section>